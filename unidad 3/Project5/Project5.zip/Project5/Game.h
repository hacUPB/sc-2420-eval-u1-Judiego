#ifndef GAME_H
#define GAME_H

#include <SDL.h>
#include "Player.h"
#include "Obstacle.h"

// Estructura para el juego
typedef struct {
    SDL_Window* window;
    SDL_Renderer* renderer;
    bool is_running;
    int last_frame_time;

    Player player;
    Obstacle obstacle;
} Game;

void Game_init(Game* game);
void Game_process_input(Game* game);
void Game_update(Game* game);
void Game_render(Game* game);
void Game_destroy(Game* game);

#endif
