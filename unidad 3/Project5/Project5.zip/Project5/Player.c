#include "Player.h"
#include "Constants.h"

void Player_init(Player* player, float x, float y, float width, float height) {
    player->x = x;
    player->y = y;
    player->width = width;
    player->height = height;
    player->vel_y = 0;
    player->is_jumping = false;
}

void Player_update(Player* player, float gravity, float delta_time, int window_height, int ground_height) {
    player->vel_y += gravity * delta_time;
    player->y += player->vel_y * delta_time;

    // Si el jugador toca el suelo, se detiene y ya no est� saltando
    if (player->y >= window_height - ground_height - player->height) {
        player->y = window_height - ground_height - player->height;
        player->vel_y = 0;
        player->is_jumping = false;
    }
}
