#include "Game.h"
#include "Constants.h"
#include <stdio.h>

void Game_init(Game* game) {
    if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
        printf("Error inicializando SDL \n");
        game->is_running = false;
        return;
    }

    game->window = SDL_CreateWindow(
        "Geometry Dash",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        WINDOW_WIDTH,
        WINDOW_HEIGHT,
        SDL_WINDOW_SHOWN
    );

    if (!game->window) {
        printf("Error creando la ventana\n");
        game->is_running = false;
        return;
    }

    game->renderer = SDL_CreateRenderer(game->window, -1, SDL_RENDERER_ACCELERATED);
    if (!game->renderer) {
        printf("Error creando el renderizador\n");
        game->is_running = false;
        return;
    }

    game->is_running = true;
    game->last_frame_time = 0;

    // Inicializa el jugador y el obst�culo
    Player_init(&game->player, 50, WINDOW_HEIGHT - GROUND_HEIGHT - 50, 50, 50);
    Obstacle_init(&game->obstacle, WINDOW_WIDTH, WINDOW_HEIGHT - GROUND_HEIGHT - 50, 50, 50, -200);
}

void Game_process_input(Game* game) {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            game->is_running = false;
        }

        if (event.type == SDL_KEYDOWN) {
            if (event.key.keysym.sym == SDLK_ESCAPE) {
                game->is_running = false;
            }
            if (event.key.keysym.sym == SDLK_SPACE && !game->player.is_jumping) {
                game->player.vel_y = -JUMP_FORCE;
                game->player.is_jumping = true;
            }
        }
    }
}

void Game_update(Game* game) {
    int time_to_wait = FRAME_TARGET_TIME - (SDL_GetTicks() - game->last_frame_time);
    if (time_to_wait > 0 && time_to_wait <= FRAME_TARGET_TIME) {
        SDL_Delay(time_to_wait);
    }

    float delta_time = (SDL_GetTicks() - game->last_frame_time) / 1000.0f;
    game->last_frame_time = SDL_GetTicks();

    // Actualiza el jugador y el obst�culo
    Player_update(&game->player, GRAVITY, delta_time, WINDOW_HEIGHT, GROUND_HEIGHT);
    Obstacle_update(&game->obstacle, delta_time, WINDOW_WIDTH);

    // Colisi�n
    if (game->player.x < game->obstacle.x + game->obstacle.width &&
        game->player.x + game->player.width > game->obstacle.x &&
        game->player.y < game->obstacle.y + game->obstacle.height &&
        game->player.y + game->player.height > game->obstacle.y) {
        game->is_running = false;
        printf("Perdiste.\n");
    }
}

void Game_render(Game* game) {
    SDL_SetRenderDrawColor(game->renderer, 0, 0, 0, 255);
    SDL_RenderClear(game->renderer);

    // Dibuja el jugador
    SDL_SetRenderDrawColor(game->renderer, 0, 255, 0, 255);
    SDL_Rect player_rect = { (int)game->player.x, (int)game->player.y, (int)game->player.width, (int)game->player.height };
    SDL_RenderFillRect(game->renderer, &player_rect);

    // Dibuja el obst�culo
    SDL_SetRenderDrawColor(game->renderer, 255, 0, 0, 255);
    SDL_Rect obstacle_rect = { (int)game->obstacle.x, (int)game->obstacle.y, (int)game->obstacle.width, (int)game->obstacle.height };
    SDL_RenderFillRect(game->renderer, &obstacle_rect);

    SDL_RenderPresent(game->renderer);
}

void Game_destroy(Game* game) {
    SDL_DestroyRenderer(game->renderer);
    SDL_DestroyWindow(game->window);
    SDL_Quit();
}
