#ifndef PLAYER_H
#define PLAYER_H

// Estructura para el jugador
typedef struct {
    float x, y;           // Posici�n
    float width, height;  // Tama�o del jugador
    int vel_y;            // Velocidad vertical
    bool is_jumping;      // Estado de salto
} Player;

void Player_init(Player* player, float x, float y, float width, float height);
void Player_update(Player* player, float gravity, float delta_time, int window_height, int ground_height);

#endif
