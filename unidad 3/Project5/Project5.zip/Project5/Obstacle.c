#include "Obstacle.h"

void Obstacle_init(Obstacle* obstacle, float x, float y, float width, float height, float vel_x) {
    obstacle->x = x;
    obstacle->y = y;
    obstacle->width = width;
    obstacle->height = height;
    obstacle->vel_x = vel_x;
}

void Obstacle_update(Obstacle* obstacle, float delta_time, int window_width) {
    obstacle->x += obstacle->vel_x * delta_time;

    // Si el obst�culo sale de la pantalla, reaparece en el borde derecho
    if (obstacle->x + obstacle->width < 0) {
        obstacle->x = window_width;
    }
}
