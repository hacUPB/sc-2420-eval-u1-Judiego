#ifndef OBSTACLE_H
#define OBSTACLE_H

// Estructura para el obst�culo
typedef struct {
    float x, y;          // Posici�n
    float width, height; // Tama�o del obst�culo
    float vel_x;         // Velocidad horizontal del obst�culo
} Obstacle;

void Obstacle_init(Obstacle* obstacle, float x, float y, float width, float height, float vel_x);
void Obstacle_update(Obstacle* obstacle, float delta_time, int window_width);

#endif
